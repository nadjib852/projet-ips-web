<?php
require_once("bdd.php");

connexion();
vidageTable();
creationTable();
creationTableUtilisateur();
insertionDonneesExemple();


?>
