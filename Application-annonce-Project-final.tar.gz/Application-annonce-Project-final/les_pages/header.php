<!DOCTYPE html> <!-- définir le type de document(pour etre imtepreter par le navigateur )-->
<html lang="en-fr"> <!-- langages anglais --> 
<head>
<meta name="viewport" content="width=device-width, minimum-scale=0.25"/>
<meta name="viewport" content="width=device-width, maximum-scale=5.0"/>
<meta name="viewport" content="width=device-width"/>
  <meta charset="utf-8"><!--pour lire les caractères français-->
  <meta name="viewport" content="width=device-width, initial-scale=1.0"><!--pour la mise en page sur les navigateur mobiles -->
  <link rel="stylesheet" href="../css/style2.css"/><!-- inclure notre fichier de css-->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  
  <title>Ofrenor | Ofrenor.fr</title> <!-- titre offre en or-->
  <header>  
        <p class="zoom"> <img /src="../les images/logo9.png"></p>
        <center>  <font size="+3"><p> Avec la livraison en point relais tout est à portée de main ! <br/></font>
        <font size="+1"><strong>1er site d'annonces gratuites de l'Hérault </strong></font> 
        </center>  
       <nav>
         <ul>
         <li> <a href="../les_pages/page_principal.php">&#9733  Acceuil</a> </li>
         <li>  <a href="../les_pages/rechercher.php">&#128269  rechercher</a> </li> 
         <li> <a href="../les_pages/visualiser_liste.php">&#9993  liste des annonces</a> </li>
         <li>  <a href="../les_pages/Deposez_une_annonce.php">&#10010  Déposez une Annonce</a> </li>

         <li style=""> <a  style="text-decoration: none" href="../les_pages/creationdecompte.php"> &#x1F46C Créer</a></li>
         

         <li style="float:right"> <a class="active" style="text-decoration: none" href="../les_pages/seconnecter.php"> &#x1F465 se connecter</a></li>
         </ul>
       </nav>
  </header>
<body>
</body>
</html>
