






<div class="container-fluid bg-light mt-5 pt-5 pb-5 border">
	<div class="row">
		<div class="col-4">
			
			 Réalisé par:<br> RAHMOUNI Nadjib <br> ABID Hamza <br>LAKHDAR-IDRISSI Meryem 
			 
			
		</div>

		<div class="col-4 justify-content-center d-flex align-items-center">
			
			 &copy;2020
			
		</div>


		<div class="col-4 justify-content-end d-flex align-items-center">
			
			 
			 <?php echo date("d-m-Y h:i:sa") ?> 
			
		</div>


	</div>
	
</div>









