<!DOCTYPE html> 
<html lang="en-fr"> <!-- langages anglais --> 
<head>
<meta name="viewport" content="width=device-width, minimum-scale=0.25"/>
<meta name="viewport" content="width=device-width, maximum-scale=5.0"/>
<meta name="viewport" content="width=device-width"/>
<link rel="stylesheet" href="../css/mobile.css"/>
<?php include '../les_pages/header.php' ?>
</head>
<body >


<div class="container " style="min-height: 40vh">
	<div class="row">
		<div class="col-6 offset-2 mt-5 pt-5">
			
			  <p class="text-justify text">
			  		Avec <strong><em>OFRENOR</em></strong> , trouvez la bonne affaire  de petites annonces de particulier à particulier et de professionnels.  trouvez la bonne occasion dans nos catégories voiture, immobilier, emploi, vacances, mode, maison, jeux vidéo, etc... Déposez une annonce gratuite en toute simplicité pour vendre, cher, donner vos biens de seconde main ou promouvoir vos services. Achetez en toute sécurité avec notre système de paiement en ligne et de livraison pour les annonces éligibles.
			   </p>
		</div>	
	

		<div class="col-4">
			<img  class="zoom2"/src="../les images/bienv.png">
			
		</div>
	</div>
</div>

  




</body>
<footer>
  <?php include '../les_pages/footer.php' ?>

  </footer>
  </html>
 











